//Compressed_Cobblestone_Blocks//
//By:MaxDistucto and supporting GitHub users.//
//Please respect my mod and don't claim it as your own.//
//198-242 unused Block IDs//
//5000 is max Item ID//
var setBlock = Block.defineBlock
var setItem = ModPE.setItem
var setSmelt = Item.addFurnaceRecipe
var setCraft = Item.addShapedRecipe
var setArmor = Item.defineArmor

setBlock(198,"Compacted Cobblestone x1",[["cobblestone",0]],198,true,0)
setBlock(199,"Compacted Cobblestone x2",[["cobblestone",0]],199,true,0)
setBlock(200,"Compacted Cobblestone x3",[["cobblestone",0]],200,true,0)
setBlock(201,"Compacted Cobblestone x4",[["cobblestone",0]],201,true,0)
setBlock(202,"Compacted Cobblestone x5",[["cobblestone",0]],202,true,0)
setBlock(203,"Compacted Diamond Block x1",[["diamond_block",0]],203,true,0)
setBlock(204,"Compacted Gold Block x1",[["gold_block",0]],204,true,0)
setBlock(205,"Compacted Iron Block x1",[["iron_block",0]],205,true,0)
setBlock(206,"Compacted Redstone Block x1",[["redstone_block",0]],206,true,0)
setBlock(207,"Compacted Obsidian x1",[["obsidian",0]],207,true,0)
setBlock(208,"Compacted Quartz Block x1",[["quartz_block",1]],208,true,0)

setItem(1498,"potion_bottle_empty",0,"2x Compactor");
setItem(1499,"fireball",0,"Compacted Obsidian x2");
setItem(1518,"potion_bottle_drinkable",1,"Compacted Diamond x648")
setItem(1519,"potion_bottle_drinkable",3,"Compacted Gold Ingot x648")
setItem(1520,"potion_bottle_drinkable",14,"Compacted Iron Ingot x648")
setItem(1521,"potion_bottle_drinkable",6,"Compacted Redstone Dust x648")
setItem(1522,"nether_star",0,"Nether Star Fragement")
setItem(399,"nether_star",0,"Nether Star")

setCraft(198,1,0,["aaa","aaa","aaa"],["a",4,0])
setCraft(199,1,0,["aaa","aaa","aaa"],["a",198,0])
setCraft(200,1,0,["aaa","aaa","aaa"],["a",199,0])
setCraft(201,1,0,["aaa","aaa","aaa"],["a",200,0])
setCraft(202,1,0,["aaa","aaa","aaa"],["a",201,0])
setCraft(201,9,0,["   "," a ","   "],["a",202,0])
setCraft(200,9,0,["   "," a ","   "],["a",201,0])
setCraft(199,9,0,["   "," a ","   "],["a",200,0])
setCraft(198,9,0,["   "," a ","   "],["a",199,0])
setCraft(4,9,0,["   "," a ","   "],["a",198,0])
setCraft(399,1,0,[" a ","aba"," a "],["a",1522,0,"b",41,0])
setCraft(1522,1,0,[" b ","cac","aaa"],["a",208,0,"b",264,0,"c",155,0])
setCraft(203,1,0,["aaa","aaa","aaa"])

