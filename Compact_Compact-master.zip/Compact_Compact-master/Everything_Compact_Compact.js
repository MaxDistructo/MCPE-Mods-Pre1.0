// All Objects and Items in the Compacted Cobblestone Mod//
// By: MaxDistructo//
// Please Respect My Mod and don't hclaim it as your own.//
//If you want to use this Mod in a mod pack, just leave credit to me and a link to my Github//
// For YT videos, leave credit to me and link to my Github and what ever website you got the mod from.//
// YT videos also need to put a link in the comments on the website so that I can see it.//
// GitHub web address is https://github.com/MaxDistructo/Compacted_Cobblestone_Items//
var setBlock = Block.defineBlock
var setItem = ModPE.setItem
var setSmelt = Item.addFurnaceRecipe
var setCraft = Item.addShapedRecipe
var setArmor = Item.defineArmor
var ironDmg = 6
var goldDmg = 5
var diamondDmg = 7
var carriedItem = Player.getCarriedItem()
var destroyTime = Block.setDestroyTime
var destoryTime = Block.setDestroyTime
function useItem(x, y, z, itemId, blockId, side){
     if(itemId==2003)
 var block=blockId
     } 

setBlock(198,"Compacted Cobblestone x1",[["cobblestone",0]],198,true,0)
setBlock(199,"Compacted Cobblestone x2",[["cobblestone",0]],199,true,0)
setBlock(200,"Compacted Cobblestone x3",[["cobblestone",0]],200,true,0)
setBlock(201,"Compacted Cobblestone x4",[["cobblestone",0]],201,true,0)
setBlock(202,"Compacted Cobblestone x5",[["cobblestone",0]],202,true,0)
setBlock(203,"Compacted Cobblestone x6",[["cobblestone",0]],203,true,0)
setBlock(204,"Compacted Cobblestone x7",[["cobblestone",0]],204,true,0)
setBlock(205,"Compacted Cobblestone x8",[["cobblestone",0]],205,true,0)

setItem(2000,"sword",2,"Unbreakable Iron Sword(WIP)",1)
setItem(2001,"sword",3,"Unbreakable Gold Sword(WIP)",1)
setItem(2002,"sword",4,"Unbreakable Diamond Sword(WIP)",1)
setItem(2003,"pickaxe",4,"Silk Touch Pickaxe (WIP)",1)

setArmor(2004,"helmet",1,"Compacted Cobblestone Chain Helmet","armor/chain_1.png",2,332)
setArmor(2005,"chestplate",1,"Compacted Cobblestone Chain Chestplate","armor/chain_1.png",5,482)
setArmor(2006,"leggings",1,"Compacted Cobblestone Chain Leggings","armor/chain_2.png",4,452)
setArmor(2007,"boots",1,"Compacted Cobblestone Chain Boots","armor/chain_1.png",1,332)
setArmor(2008,"helmet",2,"Compacted Cobblestone Iron Helmet","armor/iron_1.png",2,332)
setArmor(2009,"chestplate",2,"Compacted Cobblestone Iron Chestplate","armor/iron_1.png",6,482)
setArmor(2010,"leggings",2,"Compacted Cobblestone Iron Leggings","armor/iron_2.png",5,452)
setArmor(2011,"boots",2,"Compacted Cobblestone Iron Boots","armor/iron_1.png",2,332)
setArmor(2012,"helmet",4,"Realisticly Unbreakable Diamond Helmet","armor/diamond_1.png",3,2000000000)
setArmor(2013,"chestplate",4,"Realisticly Unbreakable Diamond Chestplate","armor/diamond_1.png",8,2000000000)
setArmor(2014,"leggings",4,"Realisticly Unbreakable Diamond Leggings","armor/diamond_2.png",6,2000000000)
setArmor(2015,"boots",4,"Realisticly Unbreakable Diamond Boots","armor/diamond_1.png",3,2000000000)

setCraft(198,1,0,["aaa","aaa","aaa"],["a",4,0])
setCraft(199,1,0,["aaa","aaa","aaa"],["a",198,0])
setCraft(200,1,0,["aaa","aaa","aaa"],["a",199,0])
setCraft(201,1,0,["aaa","aaa","aaa"],["a",200,0])
setCraft(202,1,0,["aaa","aaa","aaa"],["a",201,0])
setCraft(203,1,0,["aaa","aaa","aaa"],["a",202,0])
setCraft(204,1,0,["aaa","aaa","aaa"],["a",203,0])
setCraft(205,1,0,["aaa","aaa","aaa"],["a",204,0])
setCraft(204,9,0,["   "," a ","   "],["a",205,0])
setCraft(203,9,0,["   "," a ","   "],["a",204,0])
setCraft(202,9,0,["   "," a ","   "],["a",203,0])
setCraft(201,9,0,["   "," a ","   "],["a",202,0])
setCraft(200,9,0,["   "," a ","   "],["a",201,0])
setCraft(199,9,0,["   "," a ","   "],["a",200,0])
setCraft(198,9,0,["   "," a ","   "],["a",199,0])
setCraft(4,9,0,["   "," a ","   "],["a",198,0])
setCraft(2000,1,0,[" a "," a "," b "],["a",201,0,"b",280,0])
setCraft(2001,1,0,[" a "," a "," b "],["a",200,0,"b",280,0])
setCraft(2002,1,0,[" a "," a "," b "],["a",202,0,"b",280,0])
setCraft(2003,1,0,[" aaa "," b "," b "],["a",200,0,"b",280,0])
setCraft(2004,1,0,["aaa","a a","   "],["a",200,0])
setCraft(2005,1,0,["a a","aaa","aaa"],["a",200,0])
setCraft(2006,1,0,["aaa","a a","a a"],["a",200,0])
setCraft(2007,1,0,["   ","a a","a a"],["a",200,0])
setCraft(2008,1,0,["aaa","a a","   "],["a",201,0])
setCraft(2009,1,0,["a a","aaa","aaa"],["a",201,0])
setCraft(2010,1,0,["aaa","a a","a a"],["a",201,0])
setCraft(2011,1,0,["   ","a a","a a"],["a",201,0])
setCraft(2012,1,0,["aaa","a a","   "],["a",202,0])
setCraft(2013,1,0,["a a","aaa","aaa"],["a",202,0])
setCraft(2014,1,0,["aaa","a a","a a"],["a",202,0])
setCraft(2015,1,0,["   ","a a","a a"],["a",202,0])

function attackHook(attacker,victim){
if(carriedItem == 2000){
  Entity.setHealth(victim,Entity.getHealth(victim)-6)
}
if(carriedItem == 2001){
  Entity.setHealth(vicitm,Entity.getHealth(victim)-5)
}
if(carriedItem == 2002){
  Entity.setHealth(victim,Entity.getHealth(victim)-7)
}
} 
function destroyBlock(){
if(carriedItem == 2003){
  Level.destroyBlock(x,y,z,false)
  Player.addItemInventory(block,1,0)
}
if(carriedItem==2003){
  var defaultDestroyTime = [];
for(var j=0; j < 256; j++) defaultDestroyTime[ j ] = Block.getDestroyTime(j, 0);
//Thanks to Darkserver for putting this information on the Minecraft Fourms of how to make a silk touch pickaxe
function modTick() {
 if(Player.getCarriedItem() == 2003) {
 for(var k = 0; k < 256; k++) Block.setDestroyTime(k, 0);
 Block.setDestoryTime(7, -1);
 Block.setDestroyTime (120, -1);
 } else {
 for(var k = 0; k < 256; k++) Block.setDestroyTime(defaultDestroyTime[ k ], 0);
 }
}

function destroyBlock(x, y, z) {
 if(Player.getCarriedItem() == 2003) {
 prevent default();
 Level.destoryBlock(x, y, z, true); //destroy/drop itself
 }
}
function modTick(){
  if(carriedItem == 2003){
    destroyTime(1,0.1);
    destroyTime(4,0.1);
    destroyTime(14,0.3);
    destroyTime(15,0.3);
    destroyTime(16,0.3);
    destroyTime(21,0.3);
    destroyTime(22,0.3);
    destroyTime(24,0.1);
    destoryTime(41,0.3);
    destroyTime(42,0.3);
    destoryTime(45,0.1);
    destroyTime(48,0.1);
    destoryTime(49,0.5);
    destroyTime(52,0.3);
    destoryTime(61,0.3);
    destroyTime(62,0.3);
    destroyTime(73,0.3);
    destroyTime(74,0.3);
    destroyTime(87,0.1);
    destroyTime(89,0.3);
    destroyTime(98,0.3);
    destroyTime(101,0.3);
    destroyTime(109,0.3);
    destroyTime(112,0.3);
    destroyTime(114,0.3);
    destroyTime(116,0.5);
    destroyTime(120,0.3);
    destroyTime(121,0.3);
    destroyTime(128,0.3);
    destroyTime(129,0.3);
    destroyTime(130,0.3);
    destroyTime(139,0.3);
    destroyTime(145,0.3);
    destroyTime(152,0.3);
    destroyTime(155,0.3);
    destroyTime(156,0.3);
    destroyTime(159,0.3);
    destoryTime(172,0.3);
    destroyTime(173,0.3);
    destoryTime(198,0.3);
    destroyTime(199,0.3);
    destroyTime(200,0.3);
    destroyTime(201,0.3);
    destoryTime(202,0.3);
    destoryTime(203,0.3);
    destroyTime(204,0.3);
    destroyTime(205,0.3);} 
}} 
