# MaxDistructo's Compacted Cobble Mod and Tools for using the Cobble

Makes Cobblestone compactable and adds unbreakable tools that have special powers such as silk touch and stregnth

If you want to help, make a change to the txt file that states all the changes to the mod, if you made any changes.

